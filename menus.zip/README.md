# Gestión de Menús

Este es un proyecto de ejemplo para gestionar menús y submenús utilizando PHP 7.4, MySQL, jQuery y Bootstrap 4.

Administrador
![image](https://github.com/user-attachments/assets/c252ce33-611e-4ce8-a0b7-ee54c8a1e76c)

Sitio final menus
![image](https://github.com/user-attachments/assets/12859221-f58b-4aa8-aa28-41f3a94ecc90)

